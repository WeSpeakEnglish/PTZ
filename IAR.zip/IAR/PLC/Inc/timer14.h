#ifndef __TIMER14_H
#define __TIMER14_H
#include "variables.h"





void Timer14_Init_Deal(uint16_t ShotTime, uint8_t DealNumber);
void TIM14_IRQHandler(void);


#endif
