#ifndef __TIMER13_H
#define __TIMER13_H

#include "variables.h"



//extern uint32_t CounterUPD;
void Timer13_Init(void);
void TIM13_IRQHandler(void);


#endif
