#ifndef _LM75_H
#define _LM75_H
#include "variables.h"
void GetTempLM75(void);
#endif