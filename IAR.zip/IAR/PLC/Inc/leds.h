#ifndef _LEDS_H
#define _LEDS_H
#include <stdint.h>

void LED_control(uint8_t Status);
#endif