#ifndef _INTERRUPTS_H
#define _INTERRUPTS_H

#include "stm32f7xx_hal.h"




void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin);



#endif
